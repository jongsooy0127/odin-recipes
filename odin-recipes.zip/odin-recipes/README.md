# odin-recipes

This is the first project I have worked on through The Odin Project. Although it may seem basic and elementary, I hope everyone can understand and observe the progress I am going through via this project. 
